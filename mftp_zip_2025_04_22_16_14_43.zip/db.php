<?php
    

    $servername = "sql309.infinityfree.com";
    $username = "if0_35660366";
    $password = "gZUQ9zSluI9pT";
    $dbname = "if0_35660366_php_test";

    // $servername = "localhost";
    // $username = "root";
    // $password = "";
    // $dbname = "php_test";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
?>
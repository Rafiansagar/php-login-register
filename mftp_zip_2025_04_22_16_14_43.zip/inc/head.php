
<head>
    <!-- Meta Tags -->
    <meta charset="utf-8">
    <meta name="description" content="">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="robots" content="noindex, follow" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="assets/images/fav.png" />
    <link rel="icon" href="assets/images/fav.png" />
    <link rel="apple-touch-icon" href="assets/images/fav.png" />
    <meta name="msapplication-TileImage" content="assets/images/fav.png" />
    <!-- Meta Tags -->
    <title>Login Register PHP</title>

    <!-- Animate CSS -->
    <link rel="stylesheet" href="assets/css/vendor/animate.css">
    <!-- Remixicon CSS -->
    <link rel="stylesheet" href="assets/fonts/remixicon.css">
    <!-- Bootstarp CSS -->
    <link rel="stylesheet" href="assets/css/vendor/bootstrap.min.css">
    <!-- Spacing CSS -->
    <link rel="stylesheet" href="assets/css/st-spacing.css">
    <!-- Main Style CSS -->
    <link rel="stylesheet" href="assets/css/index.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="assets/css/responsive.css">
</head>
    
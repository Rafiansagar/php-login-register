    <!-- Modernizr js -->
	<script src="assets/js/vendor/modernizr.min.js"></script>
    <!-- Jquery Core js -->
	<script src="assets/js/vendor/jquery.min.js"></script>
    <!-- Bootstrap js -->
	<script src="assets/js/vendor/bootstrap.min.js"></script>
    <!-- Wow js -->
	<script src="assets/js/vendor/wow.min.js"></script>
    <!-- Main js -->
	<script src="assets/js/main.js"></script>

<div class="container">
    <ul class="nav-links">
        <li><a href="main_content.php">Home</a></li>
        <li><a href="index.php">Login</a></li>
        <li><a href="logout.php">Logout</a></li>
        <li><a href="signup.php">Signup</a></li>
        <li><a href="blog.php">Blog</a></li>
        <li><a href="create_blog.php">Create Blog</a></li>
        <li><a href="dashboard.php">Dashboard</a></li>
<li><a href="./sagars-app.apk">App</a></li>
    </ul>
</div>